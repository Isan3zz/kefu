# kefu 边界订单模拟数据（50 个独立新增订单）

- 对应项目实际字段：`orders` / `order_items` / `shipments` / `refund_requests`。
- 订单 ID：`O3001`–`O3050`；与原有 `O1001`–`O1004`、`O2001` 不冲突。**不覆盖原测试基线**。
- `fixture_clock_utc`：`2026-11-17T00:00:00+00:00`（项目 `app/dataset.py` 的固定时钟）。所有退款时效 Oracle 只在 `Business(db, clock=lambda: frozen_time)` 时有效。
- 商品必须先加载上一份 `kefu_products_seed_20.json`（租户 a），租户 b 的 `headphones-b` 来自 `DB.seed()`。
- 已存在账号只使用 `user_a`、`admin` 和 `user_b`；`admin` 的订单是为测试**同一租户、不同 user_id** 的隔离，不应被 `user_a` 看到。

## 文件

- `kefu_orders_boundary_50.json`：全部 DB 行，按表分别列出；可按需选择子集装入隔离 fixture。
- `kefu_orders_boundary_50.sql`：直接插入 SQL（先导入商品、用户），每张表按依赖顺序插入，按 ID `ON CONFLICT DO NOTHING`，重复运行不覆盖业务状态。
- `kefu_orders_boundary_50_oracle.json`：**仅供评测使用**的订单级 Gold 标签；不要传给 LLM，不要作为工具内容。

## 数据规模

- 订单：50；订单明细：61；物流记录：58；已有退款申请：2。
- 付款状态：{'PAID': 13, 'SHIPPED': 13, 'DELIVERED': 21, 'CANCELLED': 2, 'RETURNED': 1}。
- 退款资格：{'ELIGIBLE': 20, 'HUMAN_REVIEW': 15, 'INVALID_AMOUNT': 2, 'EXPIRED': 5, 'MISSING_DELIVERY_TIME': 3, 'INVALID_STATUS': 3, 'ALREADY_EXISTS': 2}。
- 有意识的脏数据：`INVALID_AMOUNT` (金额 0 或负数)、`PAID` 与物流状态不一致、实付与明细总额不一致、已送达但缺少/未来签收时间、未知状态 `RETURNED`。

## 关键边界与现有代码语义

1. `PAID` + `待发货` 或**无物流行**：`ELIGIBLE`；`PAID` + `运输中/已签收`：`HUMAN_REVIEW`。
2. `SHIPPED` 一律为 `HUMAN_REVIEW`，不因物流异常自动创建工单（系统目前没有“物流超过 72 小时创建工单”的自动业务规则）。
3. `DELIVERED` + 7*24 小时以内（**含恰好 7 天**）：`ELIGIBLE`；超出 1 秒：`EXPIRED`；缺失 `delivered_at`：`MISSING_DELIVERY_TIME`。
4. 未来签收时间当前也返回 `EXPIRED`，这是测试真实源码语义，不代表理想业务解释。
5. 已有 `refund_requests` 的订单：`ALREADY_EXISTS`；`CANCELLED`/`RETURNED`：`INVALID_STATUS`；付款金额 <= 0：`INVALID_AMOUNT`。
6. 实付金额与 `order_items` 不一致但实付仍大于 0 时，**当前** `Business.eligibility` 并不校验明细总额；Oracle 为 `ELIGIBLE`，建议额外记录为数据完整性问题而不是静默修改期待值。
7. `user_a` 应看不到 `admin` 的订单（同租户不同用户）以及 `user_b` 的订单（跨租户）；`Business.owned` 返回 `NOT_FOUND`。
8. 部分订单含多条物流历史。当前 `Business.tool('track_shipment')` 返回**未明确排序**的物流列表，不能未经排序就声称第一条/最后一条是“最新状态”。

## Codex 导入与评测注意事项

1. **仅在隔离 SQLite 评测库中导入**，先执行 `DB.seed()`，再加载此前的 20 商品，最后导入本数据。确认不能污染真实用户或演示库。
2. 不要直接修改默认 `DB.seed()` 中 O1001 等订单，更不要让新增订单改变现有“第二单 O1002”的单测预期。评测时建议按 case 选择订单子集，避免 50 条订单在 `get_orders(limit=10)` 中被截断。
3. 现有 `app/dataset.py` 仅支持 `fixture='user_a_delivered_refundable'`，`app/evaluation.py` 每次 `db.seed(clock)` 且写死 `Actor('user_a','a')`。要跑这些 Oracle，需要先新增 fixture selector/loader，以及跨用户执行入口；这一步不可仅靠向 `datasets/agent_loop.jsonl` 加案例完成。
4. 现有评测用 `refund_request_count_delta=len(refunds)`，是结果总数，**不是**相对于初始退款行数的差值。导入这里的已有退款记录后必须修改成 `after-before`，否则会把初始申请计为 Agent 新增写入。
5. 快照内时间固定，不应在真实墙上时钟环境下断言“恰好 7 天”结果。需要交互式演示时可对相对时间字段整体平移并同步冻结业务时钟与预期值。
6. 数据中商品 `stock=0` 不代表历史订单非法（商品过去售出、当前缺货可以同时成立）；不要在历史订单装载中调用实时库存扣减。
7. Oracle 不能混入 Agent 可检索的知识库、提示词或 MCP 工具结果，避免答案泄漏。
8. SQL 只保证按 ID 重复导入不会增加记录，不会覆盖已有变化；更严格的 fixture 加载应在隔离库执行并验证同 ID 的数据内容，避免把旧版本数据静默当成新版本。

## 推荐验收

- FK/引用完整性、订单号唯一、金额一致性（**有意异常单独标记**）、用户/租户商品归属。
- 冻结时钟下逐订单 `Business.eligibility` 与 Oracle 逐条比对。
- 同租户与跨租户的 `Business.owned` 拒绝。
- `get_order`、`track_shipment` 仅返回拥有者数据，并覆盖多条物流/缺失物流。
- 对 `ALREADY_EXISTS` 订单反复申请退款，验证无新增写入。
- 退款预览/确认场景采用**独立测试副本**，避免某个 case 的受理记录污染别的 case。
