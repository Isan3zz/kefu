# kefu Agent 首批 100 条端到端任务

## 文件及用途

- `kefu_e2e_10_smoke.jsonl`：先检查导入、RAG、退款与执行链路的 10 条子集（不参与最终 100 条统计）。
- `kefu_e2e_100.jsonl`：严格遵循仓库 `app/dataset.py::Case` 的可解析 JSONL 格式，100 个独立 case；每个 case 有显式的 `expected` 工具/工作流/安全断言。
- `kefu_e2e_100_oracle.jsonl`：对应 100 条任务的答案事实、相关商品 ID、禁止断言、人工审查说明。**此文件不是仓库内置评测器的输入**，不能和测试 JSONL 混在一起。
- `kefu_e2e_100_overview.csv`：任务、用户及预期要点的一页式表格，方便审查、纠错和发给 Codex。
- `kefu_e2e_100_review_template.csv`：逐个 case 的答案正确性标注表。运行后审查答案，填 `semantic_pass=yes/no`。
- `score_kefu_e2e.py`：合并自动断言和人工答案审查，不把“只有工具调用正确”误算为端到端成功。
- `kefu_e2e_fixture.patch`：给原有隔离 eval 初始化补充 20 个商品测试数据的最小补丁。

## 100 条分布

| 场景 | 数量 | ID |
|---|---:|---|
| 商品咨询与推荐 | 20 | e2e-001 至 e2e-020 |
| RAG 知识检索与证据 | 15 | e2e-021 至 e2e-035 |
| 订单查询、物流、上下文指代 | 20 | e2e-036 至 e2e-055 |
| 退款、确认、取消和幂等 | 20 | e2e-056 至 e2e-075 |
| 跨工具复合任务 | 15 | e2e-076 至 e2e-090 |
| 权限、诱导越权、事实可靠性 | 10 | e2e-091 至 e2e-100 |

## 重要：不补测试 Fixture 会出现误判

当前 `app/evaluation.py::run()` 为每个普通 case 调用 `db.seed(clock)`，其默认数据库只有两租户各一款“云听耳机”，不会自动载入完整 20 款商品；因此前 20 条商品测试，以及多工具商品任务，会因测试数据不完整而失败。

已附 `kefu_e2e_fixture.patch`，只在带 `e2e-100` tag 的评测 case 中导入完整的 20 商品集，且补齐基础商品静态 `attributes_json` 属性；不影响普通评测和业务环境。让 Codex 审核并应用补丁后再执行任务。

本包**没有**自动加入用户画像 Fixture，因为仓库通用 `run_eval` 还不支持在 case 级别初始化记忆或变更 Memory On/Off；本轮专门量化 Agent 的编排、工具选择、业务正确性与知识问答。记忆另做独立 A/B 测试，避免混淆分母。

## 执行步骤（在 kefu 项目根目录）

1. 复制 `kefu_e2e_100.jsonl` 到 `datasets/kefu_e2e_100.jsonl`，应用 `kefu_e2e_fixture.patch`，确保已下载本地 BGE embedding 与 reranker。
2. 确认本地知识库已经通过 `python -m scripts.build_kb` 成功构建，且使用与当前模型权重一致的快照；否则 RAG 相关任务会因环境未就绪而失败。
3. 建议先试运行 `python -m scripts.run_eval --dataset datasets/kefu_e2e_10_smoke.jsonl --mode agent-real`（须先将 smoke 文件复制到 `datasets/`）。确认数据、权限和状态断言均正常后，再运行完整 100 条。配好真实模型环境变量 `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`，执行以下命令：

   ```bash
   python -m scripts.run_eval --dataset datasets/kefu_e2e_100.jsonl --mode agent-real --skill-mode selected
   ```

4. `data/eval_runs/<run-id>/report.json` 保存每条 case 的 `passed`、`answer`、`tools`、`final_state`、`traces`。把 `answer` 与 `kefu_e2e_100_oracle.jsonl` 中各 case 的 `required_answer_facts`、`forbidden_claims` 比对，逐行填写 `kefu_e2e_100_review_template.csv` 的 `semantic_pass=yes/no`。
5. 在有 Python 3 的环境执行：

   ```bash
   python score_kefu_e2e.py --report data/eval_runs/<run-id>/report.json --review kefu_e2e_100_review_template.csv
   ```

## 严格成功率的分母和边界

推荐成功标准：一个 case 的**工具与工作流自动断言全部通过**，同时**最终回答事实、引用或拒绝行为满足人工 Oracle**，才记作 `strict_success=True`。100 条任务均独立初始化数据库；成功率采用 `strict_success_count / 100`，另报告 `UNKNOWN_OUTCOME`、超时、模型调用与 p95 延迟。

切记：仓库当前 `app/evaluation.py` 的 JSONL `expected` 只支持工具/流程/安全断言，**不能直接检查推荐的商品 ID、回答事实是否完整、是否满足预算或缺货约束**；因此它的 `passed/total` 只能称作“自动断言通过率”，不能未经人工/独立 Judge 检验就写成端到端任务成功率。

在越权/不存在订单场景，合规的结果可以是提前拒绝，也可以是工具返回 NOT_FOUND 后正确拒绝。当前原生 Evaluator 对预期安全失败的工具事件可能按 `tool_execution` 计为失败，且某些 `required_tools` 会惩罚“提前正确拒绝”；建议第二步让 Codex 扩展评测器表达“允许安全拒绝或已授权查询返回 NOT_FOUND”的多分支 Oracle，再把它用于正式跑分。**不要为了提高通过率而削弱后台权限校验。**

商品目录中 `stock=0` 的 Mini、Run、Ultra、Outdoor 等，任务中引用相关 `expected_product_ids` 仅表示“需要核实此商品”，**不表示该商品应被推荐为现货**。需要统一从实时产品表确认价格与库存，不以 RAG 静态商品说明作为实时库存数据。

## 版本说明

任务设计依据 2026-11-19 `main` 分支源码：`app/db.py`、`app/product_fixtures.py`、`kefu_products_seed_20.json`、`app/evaluation.py`、`app/dataset.py`、`app/agent_loop.py`、`app/loop_tools.py`、`app/business.py`。这份任务包未经真实 LLM 执行，**不包含或暗示测试成绩**。
