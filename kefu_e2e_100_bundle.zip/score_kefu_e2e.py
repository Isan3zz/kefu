#!/usr/bin/env python3
"""Merge the repository's deterministic assertions with independent answer-quality review.

Use only after a reviewer marks semantic_pass=yes/no for ALL 100 cases.
Unknown outcomes and missing reviewer labels are not silently marked as success.
"""
import argparse, csv, json
from collections import Counter
from pathlib import Path


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--report',type=Path,required=True,help='data/eval_runs/<run-id>/report.json')
    ap.add_argument('--review',type=Path,default=Path('kefu_e2e_100_review_template.csv'))
    ap.add_argument('--output',type=Path,default=Path('kefu_e2e_100_scores.json'))
    a=ap.parse_args()
    report=json.loads(a.report.read_text(encoding='utf-8'))
    with a.review.open(newline='',encoding='utf-8-sig') as f:
        review={r['case_id']:r for r in csv.DictReader(f)}
    rows=report['cases']; ids=[row['case_id'] for row in rows]
    if len(ids)!=100 or len(set(ids))!=100:
        raise SystemExit(f'Expected 100 unique cases, got {len(ids)}')
    if set(ids)!=set(review):
        raise SystemExit('Review CSV does not match report case IDs')
    results=[]; human_pending=0; automatic_pass=0; strict_pass=0; unknown=0
    for row in rows:
        ident=row['case_id']; label=review[ident].get('semantic_pass','').strip().lower()
        if label not in ('','yes','no','true','false','1','0','通过','不通过'):
            raise SystemExit(f'Invalid semantic_pass in {ident}: {label!r}')
        semantic=None if not label else label in ('yes','true','1','通过')
        if semantic is None:human_pending+=1
        auto=row['passed']
        if auto is True:automatic_pass+=1
        if auto is None:unknown+=1
        success=auto is True and semantic is True
        if success:strict_pass+=1
        results.append({'case_id':ident,'group':review[ident]['group'],'automatic_pass':auto,
                        'semantic_pass':semantic,'strict_success':success if semantic is not None else None,
                        'review_note':review[ident].get('reviewer_note','')})
    summary={'run_id':report['run_id'],'total':100,'auto_pass':automatic_pass,'auto_pass_rate':automatic_pass/100,
             'unknown_outcome':unknown,'review_pending':human_pending,'strict_e2e_success':strict_pass if not human_pending else None,
             'strict_e2e_success_rate':strict_pass/100 if not human_pending else None,
             'warning':'自动断言不等同于真实 E2E 成功率；严格成功要求自动断言和答案审核同时通过。'}
    a.output.write_text(json.dumps({'summary':summary,'cases':results},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    if human_pending:print(f'尚有 {human_pending} 条答案未审查：目前不能计算 100 条任务的严格端到端成功率。')

if __name__=='__main__':main()
