# kefu 模拟 RAG 知识包 v3（50 篇 + 60 条标注）

此包专门对应 `Isan3zz/kefu` 当前 `app.rag.RAG.build()` 的 Markdown YAML Frontmatter、`paragraph-v2-400-60` 分块逻辑，以及现有 `datasets` 合同。**全是虚构模拟资料，不代表现实售后政策。**

## 内容

- `knowledge/expansion_v3/manuals/`：20 篇，对应上一批 `kefu_products_seed_20.json` 中的 20 个商品。全部 `tenant_id: a`，`visibility: customer`，为静态规格；不固化实时库存与售价。
- `knowledge/expansion_v3/policies/`：8 篇，售后、退款确认、保修、价保、支付及权限；与项目 `Business.eligibility` 中 P-REFUND-v1 规则一致。
- `knowledge/expansion_v3/troubleshooting/`：8 篇，故障诊断和多文档关联问题。
- `knowledge/expansion_v3/logistics/`：6 篇，物流状态、72 小时*演示核查阈值*、签收争议、修改地址。
- `knowledge/expansion_v3/special/`：8 篇，过期/归档/未来/草稿/内部/跨租户/伪指令等边界样本。
- `datasets/rag_v3_gold_60_extended.jsonl`：60 条人工设计 gold，其中 52 条有合法检索证据、8 条负例；含 gold_document、gold_chunk、租户与否定原因。
- `datasets/rag_v3_positive_52_compatible.jsonl`：52 条正例，格式符合当前 `app/dataset.py` 的 retrieval Case 模型；**最后一条属于租户 B，必须先改造评测身份后才能正确运行**。
- `datasets/rag_v3_positive_51_tenant_a_ready.jsonl`：默认评测身份 `user_a` 下可直接执行的 51 条正例。
- `datasets/rag_v3_positive_01_tenant_b_adapter_required.jsonl`：租户 B 的正例，等 Codex 实现按用例选择租户后再执行。
- `gold_evidence_chunk_map.json`：基于当前 chunker 计算的每篇文档所有 chunk_id。
- `scripts/validate_kb_fixture.py`：独立校验 Markdown 元数据、数量、商品关联、前置证据和 Chunk ID（依赖 PyYAML）。

## Codex 导入步骤

1. 不要删除原有知识文件；将本包中 `knowledge/expansion_v3/` 整个目录复制到仓库根目录 `knowledge/expansion_v3/`。新增文档 `id` 使用 `kbv3_*` 命名空间，避免覆盖原来的 30 篇知识。
2. 将 `datasets/` 两个评测文件放入项目 `datasets/`，它们不会覆盖原有的 `retrieval.jsonl`。
3. **商品数据库准备**：使用上一批 `kefu_products_seed_20.json` 且保证 id 一致；商品手册只含静态属性，商品售价和库存以 MCP 实时工具为准。
4. 用已下载的本地 BGE-M3 / BGE-reranker-v2-m3 执行 `python -m scripts.build_kb` 重建 Chroma + BM25 快照。
5. 用 `python -m scripts.run_eval --dataset datasets/rag_v3_positive_51_tenant_a_ready.jsonl --mode rag-real --retrieval-mode hybrid_rerank` 运行正例检索。根据 51 个 case 的 Query、gold_chunks、Recall@5、MRR@10、失败来源检查结果；与 bm25/dense/hybrid 对比，**不能保证未经运行的指标**。
6. 60 条扩展集中的 8 条负例涉及：未授权/不存在资料要拒答；已归档/未生效规则要以现行规则反驳错误前提；提示注入要拒绝非法操作。它们不符合当前 `Case.category=retrieval` 必须存在非空 `gold_chunks` 的合同。请为负例新增**独立适配评估**：无权文档不能进入候选或结果，未发布和过期资料不得被引用；未提供的产品能力/位置应拒绝编造。不要通过伪造 `gold_chunks` 让负例混入 Recall@5。
7. **重要**：现有 `app/evaluation.py` 的 `case_workspace` 默认仅 Seed 既有 `user_a`/`user_b`，普通 `rag-real` 运行时 RAG tenant 固定使用 `user_a` 的租户。第 52 条本包 `tenant_id=b` 的租户 B 专属正例不适合直接沿用默认上下文。为避免假失败，默认先使用 51 条租户 A 的文件；必须扩展评测为每条检索 case 明确设置 tenant 后，才能测试租户 B 场景。绝不可把租户 B 专属文档改成 public 来使测试通过。
8. 当前文档都使用独特 `id`，实际构建会把新旧知识一起索引。已归档、过期、未来、草稿或 `visibility=internal` 的文档**可能存储在索引中**，但搜索时必须通过 `RAG.visible()` 阻止返回。索引存储与搜索可见不是同一个概念。
9. 因当前代码 `chunk_id` 是根据 `文档ID:版本:块索引:块内容hash` 计算的，本文件包为当前文档计算了确定性 gold_chunk_id。**任何修改正文都会改变对应 chunk_id**，应按新的实际快照重建 gold 映射。
10. 需要做答案层、Agent 多轮补充检索或引用审查时，使用扩展集中的 gold_documents、evidence_anchor、expected_behavior 作为人工校验依据，不能单靠 Recall@5 判定最终回答是否正确。

## 风险与兼容性

- `app.rag.chunks` 默认 `size=400, overlap=60`；如果上游改动 chunker 或 YAML 正文，必须重新对齐标签。
- 旧项目文档中出现已过时的普通售后内容时，不能用本包冒充真实法规或客服制度；以当前后端逻辑为准。
- 订单模拟数据中包括故意脏数据，不能让 RAG 文档提供伪造订单实况；订单状态、本人权限、金额及物流时间仍须 MCP 工具查询。
- 没有修改 LangGraph Agent Loop、退款受保护写工具、数据库 Schema，也不声称这些案例已通过真实 BGE 测试。
- 文档里演示 72 小时物流核查阈值**不是自动触发的系统业务规则**；若要形成条件式创建工单任务，需另写精确评测和可信时间检查。
