"""Validate the generated kefu RAG fixture as standalone files."""
import json,hashlib
from pathlib import Path
from collections import Counter
import yaml
ROOT=Path(__file__).resolve().parents[1]

def chunk(text,size=400,overlap=60):
    text=text.strip(); result=[]; start=0
    while start<len(text):
        end=min(start+size,len(text))
        if end<len(text):
            boundary=text.rfind('\n\n',max(start+size//2,start+overlap+1),end)
            if boundary>=0:end=boundary+2
        piece=text[start:end]
        if piece.strip():result.append(piece)
        if end==len(text):break
        start=end-overlap
    return result

def main():
    docs={}; chunks={}
    for path in sorted((ROOT/'knowledge'/'expansion_v3').rglob('*.md')):
        content=path.read_text(encoding='utf8')
        assert content.startswith('---\n'),path
        _,front,body=content.split('---',2)
        meta=yaml.safe_load(front)
        for key in ('id','title','version','tenant_id','status','visibility','effective_at'):
            assert key in meta,(path,key)
        assert meta['id'] not in docs,meta['id']
        docs[meta['id']]=meta
        parts=chunk(body)
        chunks[meta['id']]=[]
        for index,piece in enumerate(parts):
            h=hashlib.sha256(piece.encode()).hexdigest()
            cid=hashlib.sha256(f"{meta['id']}:{meta['version']}:{index}:{h}".encode()).hexdigest()[:24]
            chunks[meta['id']].append(cid)
    assert len(docs)==50,len(docs)
    cases=[json.loads(x) for x in (ROOT/'datasets'/'rag_v3_gold_60_extended.jsonl').read_text(encoding='utf8').splitlines() if x]
    compatible=[json.loads(x) for x in (ROOT/'datasets'/'rag_v3_positive_52_compatible.jsonl').read_text(encoding='utf8').splitlines() if x]
    a_ready=[json.loads(x) for x in (ROOT/'datasets'/'rag_v3_positive_51_tenant_a_ready.jsonl').read_text(encoding='utf8').splitlines() if x]
    assert len(cases)==60 and len(compatible)==52 and len(a_ready)==51
    assert len({x['case_id'] for x in cases})==60
    for row in cases:
        if row['kind']=='negative':
            assert not row['gold_chunks'] and row['expected_behavior'] in ('abstain_or_clarify','reject_invalid_premise_with_current_policy','deny_unauthorized_knowledge','refuse_unsafe_action')
        else:
            assert len(row['gold_chunks'])==len(row['gold_documents'])
            for ref in row['gold_evidence']:
                assert ref['document_id'] in docs
                assert ref['chunk_id'] in chunks[ref['document_id']],ref
    cm={x['case_id']:x for x in cases}
    for row in compatible:
        assert row['expected']['gold_chunks']==cm[row['case_id']]['gold_chunks']
    original=json.loads((ROOT/'source'/'kefu_products_seed_20.json').read_text(encoding='utf8'))
    assert len(original)==20
    assert all('kbv3_product_'+p['id'].replace('-','_') in docs for p in original)
    print('OK 50 docs, 60 extended gold, 52 compatible retrieval cases, '+str(sum(map(len,chunks.values())))+' chunks')
if __name__=='__main__':main()
