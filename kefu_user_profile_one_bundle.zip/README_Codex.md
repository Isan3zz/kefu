# 单用户画像注入 & 工具调用验证（kefu）

## 文件
- `user_a_memory_profile.json`：一个现有用户 `a/user_a` 的四条长期记忆输入；不是新用户，也不是新增数据库字段。
- `profile_test_cases.json`：4 个专项测试案例与人工/程序校验点，**不属于当前项目 `app/dataset.py` 已接受的 JSONL 格式**；需要 Codex 编写一个轻量测试适配器。

## 导入方式（务必按当前项目真实 Memory API 进行）
1. 在**隔离 SQLite/Chroma** 评测环境加载原有 `DB.seed()`、此前 20 个商品种子（如已集成）和现有 RAG 索引。不要在生产用户账号上写测试记忆。
2. 使用现有 `user_a` 身份，不创建新账号。调用 `MemoryService.update_settings(principal, retrieval_enabled=True)`；`auto_write_enabled` 可保持 `False`，因为这次用的是**手工创建记忆**，不是测试自动提取。
3. 对 `memory_inputs` 每项执行 `MemoryService.create_memory(principal, MemoryInput.model_validate(row))`，由已有的 Chroma Memory Index 进行索引。不要绕过 MemoryService 直接插 SQLite，否则可能漏掉向量索引、版本字段和归属控制。
4. 用 `list_memories` 核对四条 active 的 `subject_key`；通过同一个用户执行测试。
5. 以 `mode=real` 使用支持原生 Tool Calling 的主模型，保留 Trace/Telemetry；Fake/deterministic 模式只能作为协议 smoke，不能证明真实模型会依据画像选工具。
6. `profile-on-001` 运行前先确认 `memory.search` 有命中，`ContextManager` 中 USER_MEMORY 被正确注入，再检查主模型调用 `search_products` 并结合真实商品推荐。为避免泄露私人上下文，日志仅记录 memory_id/subject_key 等安全元数据，测试中可对隔离运行的上下文做短暂断言，不将全文上传到公开报告。
7. 同样的提问在 `retrieval_enabled=False` 下运行 `profile-off-002`，随后恢复原设置；用来比较画像实际使用情况。注意关闭记忆后依然应该调用 `search_products`，**不代表画像没有发挥作用**。
8. 再跑当轮预算覆盖历史预算 `profile-current-budget-003`、与画像无关的物流请求 `profile-unrelated-004`。

## 源码约束（已核对）
- `MemoryInput` 仅允许 `memory_type` / `subject_key` / `content`，且类型是 preference / stable_constraint / stable_fact；本数据符合契约。`subject_key=headphones.budget` 配合 `memory_type=stable_constraint` 可被 `app/memory/recommendations.py:budget_for()` 识别。
- `app/agent_loop.py` 当前只对被 `recommendation_request()` 识别的推荐类请求召回记忆，而且**当轮明确预算已出现时可能跳过召回**。不要把所有提问都标成应召回；如果优化门禁需另立实验。
- `search_products` 工具 Schema 只有 `keyword`、`limit`，后端按商品名称查询；没有预算、ANC、佩戴类型、双设备连接过滤参数。需求是让 Agent 使用记忆、调用工具、基于结果选择，而不是凭空要求工具支持未实现的结构化筛选。
- 当前最终回答渲染会列出部分商品，并且 `display_product()` 只显示有限属性。若 `profile-on-001` 没有明确给出推荐依据，应以真实运行失败为起点，进行**最小范围**商品结果摘要/排序改进，不能仅因回答列出了 Office 就算个性化推荐成功。
- 20 商品数据中的 `yt-office-headset` 为唯一满足：租户 a、头戴式、ANC、双设备连接、预算 ≤500 元且库存 >0 的型号（价格 459 元、库存 12）。该 Gold 是按随包产品 Fixture 静态核对的，不应依赖模型臆测。

## Codex 任务
> 把附件的数据作为隔离 Fixture，利用现有 MemoryService 注入 user_a 的四条画像记忆，验证记忆检索和 Context 注入、search_products 工具调用，以及基于商品属性的推荐结果。实现 Memory On/Off 对照和当轮预算覆盖、无关物流对照。不要修改 DB Schema，不新增 Agent、不预设测试 PASS。若需要断言模型的决策，调用真实 Tool Calling 模型并保留关键 Trace；在 Fake 模型下只作静态与协议测试。
